package com.wipro.water.util;

public class InvalidInputException extends Exception{
	@Override
	public String toString() {
		
		return "INVALID INPUT";
	}

}
