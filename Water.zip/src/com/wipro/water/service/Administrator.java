package com.wipro.water.service;

import com.wipro.water.bean.WaterBillBean;

public class Administrator {
	public String addWaterBill(WaterBillBean waterBill){
		return null;
		
	}
	public WaterBillBean viewWaterBill(int consumerNumber,String billMonth,String year){
		return null;
		
	}
}
