package com.wipro.water.dao;

import com.wipro.water.bean.WaterBillBean;

public class WaterBillDAO {
	public String createWaterBill(WaterBillBean waterBill){
		return null;
		
	}
	public WaterBillBean fetchWaterBill(int  consumerNumber,String billMonth,String year){
		return null;
		
	}
	public boolean waterBillExists(int consumerNumber,String billMonth,String year){
		return false;
		
	}
}
